// import 'dart:convert';
//
// import 'package:cloud_firestore/cloud_firestore.dart';
// import 'package:finalproject/screen/timer/appbar.dart';
// import 'package:finalproject/screen/timer/clock.dart';
// import 'package:firebase_auth/firebase_auth.dart';
// import 'package:flutter/material.dart';
//
// import 'package:google_fonts/google_fonts.dart';
// import 'package:custom_timer/custom_timer.dart';
// import 'package:intl/intl.dart';
// import 'package:quickalert/models/quickalert_type.dart';
// import 'package:quickalert/widgets/quickalert_dialog.dart';
// import 'package:shared_preferences/shared_preferences.dart';
//
// import '../../controller/method.dart';
// import '../../widgets/intro.dart';
// import '../rate/rate.dart';
//
// class HomeTimer extends StatefulWidget {
//   const HomeTimer({super.key});
//
//   @override
//   State<HomeTimer> createState() => _HomeTimerState();
// }
//
// class _HomeTimerState extends State<HomeTimer> {
//   CustomTimerController controller = CustomTimerController();
//
//   var format = DateFormat("HH:mm");
//   late DateTime timeNow;
//   late DateTime differenceTime;
//   late DateTime end;
//   late Duration duration;
//   late int dura;
//   List dBefore = [];
//   List dafter = [];
//   List iAfter = [];
//   List iBefore = [];
//
//   bool isAfter = false;
//   bool isBefore = false;
//   String? faculty;
//   String? time;
//   String? location;
//   String? sTime;
//   List userBooking = [];
//
//   void setCounter(String endTime) {
//     var x = DateTime.now();
//     var formattedDate = DateFormat('kk:mm').format(x);
//     timeNow = format.parse(formattedDate);
//     end = format.parse(endTime);
//     print('--------------------------');
//     print('Now    $timeNow');
//     print('Time    $time');
//     print(end);
//     print('--------------------------');
//     if (timeNow.isBefore(end)) {
//       isBefore = true;
//       iBefore.add(isBefore);
//       duration = end.difference(timeNow);
//       dBefore.add(duration);
//       print('now before end ');
//     } else if (timeNow.isAfter(end)) {
//       isBefore = false;
//       isAfter = true;
//       iAfter.add(isAfter);
//       var xx = timeNow
//           .difference(end)
//           .inMinutes;
//       if ((60 - xx >= 0) && (60 - xx) <= 60) {
//         dura = 60 - xx;
//         dafter.add(dura);
//       } else {
//         dura = 0;
//         dafter.add(dura);
//       }
//
//       print('end after now');
//     } else {
//       print('difference = ${end.difference(timeNow)}');
//     }
//   }
//
//   Future getBook() async {
//     var prefs = await SharedPreferences.getInstance();
//     faculty = prefs.getString('faculty') ?? "";
//     time = prefs.getString('time') ?? "";
//     sTime = prefs.getString('sTime') ?? "";
//     location = prefs.getString('location') ?? "";
//     // setCounter();
//
//     return time;
//   }
//
//   Future getDataUser() async {
//     dafter.clear();
//     dBefore.cast();
//     var prefs = await SharedPreferences.getInstance();
//     print('userBooking $userBooking');
//     String? encodedMap = prefs.getString('userBooking') ?? "";
//     print('userBooking $userBooking');
//     userBooking = json.decode(encodedMap);
//     return userBooking;
//   }
//
//   update() async {
//     var updatePosition = FirebaseFirestore.instance
//         .collection('parking')
//         .doc(faculty)
//         .collection('Time')
//         .doc(sTime);
//     updatePosition.set(
//       {
//         'position': {location: true}
//       },
//       SetOptions(merge: true),
//     );
//
//     FirebaseFirestore.instance
//         .collection('parking')
//         .doc(faculty)
//         .collection('Time')
//         .doc(sTime)
//         .get()
//         .then((value) {
//       var updatePosition = FirebaseFirestore.instance
//           .collection('parking')
//           .doc(faculty)
//           .collection('Time')
//           .doc(sTime);
//       updatePosition.set(
//         {'count': value.data()!['count'] - 1},
//         SetOptions(merge: true),
//       );
//     });
//   }
//
//   String? user = FirebaseAuth.instance.currentUser?.uid;
//   String name = '';
//
//   getData() async {
//     await FirebaseFirestore.instance
//         .collection('Users')
//         .doc(user)
//         .get()
//         .then((value) {
//       setState(() {
//         name = value['Username'];
//       });
//     });
//   }
//
//   @override
//   void initState() {
//     super.initState();
//     getData();
//     controller.start();
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     print('time $time');
//     var we = MediaQuery
//         .of(context)
//         .size
//         .width;
//     var he = MediaQuery
//         .of(context)
//         .size
//         .height;
//
//     return SafeArea(
//       child: Scaffold(
//         backgroundColor: const Color(0xffE3EDF7),
//         body: FutureBuilder(
//           future: getDataUser(),
//           builder: (context, snapshot) {
//             print("snapshot ${snapshot.data}");
//             userBooking.forEach((element) {
//               setCounter('24:50');
//             });
//             if (snapshot.hasData) {
//               return Container(
//                 height: double.infinity,
//                   alignment: Alignment.center,
//                   child: SingleChildScrollView(
//                     physics:ScrollPhysics(),
//                     child: Column(
//
//                       children: [
//                         const SizedBox(
//                           height: 15,
//                         ),
//                         const Appbars(),
//                         const SizedBox(
//                           height: 25,
//                         ),
//                         RichText(
//                           text: TextSpan(
//                             children: <TextSpan>[
//                               TextSpan(
//                                 text: DateTime
//                                     .now()
//                                     .hour <= 12
//                                     ? 'Good Morning, \n  $name,  '
//                                     : 'Good Evening, \n  $name,  ',
//                                 style: const TextStyle(
//                                   height: 1.3,
//                                   color: Colors.blueGrey,
//                                   fontWeight: FontWeight.w600,
//                                   fontSize: 20,
//                                 ),
//                               ),
//                               const TextSpan(
//                                 text: 'Have a nice day.!',
//                                 style: TextStyle(
//                                   color: Colors.amber,
//                                   fontWeight: FontWeight.w600,
//                                   fontSize: 18,
//                                 ),
//                               ),
//                             ],
//                           ),
//                         ),
//                         SizedBox(height: he * 0.05),
//                         const ClockView(),
//                         Expanded(
//                           child: ListView.separated(
//                               shrinkWrap: true,
//                               itemBuilder: (context, index) =>
//                               Column(
//                                 children: [
//                                   Container(
//                                     width: double.infinity,
//                                     padding: const EdgeInsets.all(9),
//                                     child: Row(
//                                       mainAxisAlignment:
//                                       MainAxisAlignment.spaceEvenly,
//                                       children: [
//                                         Column(
//                                           crossAxisAlignment:
//                                           CrossAxisAlignment.start,
//                                           children: [
//                                             Text(
//                                               'Faculty  :',
//                                               style: GoogleFonts.roboto(
//                                                   fontSize: 25,
//                                                   color: Colors.blueGrey,
//                                                   fontWeight: FontWeight.w700),
//                                             ),
//                                             const SizedBox(
//                                               height: 4,
//                                             ),
//                                             Text(
//                                               'Time  :',
//                                               style: GoogleFonts.roboto(
//                                                   fontSize: 25,
//                                                   color: Colors.blueGrey,
//                                                   fontWeight: FontWeight.w700),
//                                             ),
//                                             const SizedBox(
//                                               height: 4,
//                                             ),
//                                             Text(
//                                               'Location  :',
//                                               style: GoogleFonts.roboto(
//                                                   fontSize: 25,
//                                                   color: Colors.blueGrey,
//                                                   fontWeight: FontWeight.w700),
//                                             ),
//                                           ],
//                                         ),
//                                         // Expanded(child: Container()),
//                                         Column(
//                                           crossAxisAlignment:
//                                           CrossAxisAlignment.start,
//                                           children: [
//                                             Text(
//                                               userBooking[index]['faculty'],
//                                               style: GoogleFonts.roboto(
//                                                   fontSize: 25,
//                                                   color: Colors.blueGrey,
//                                                   fontWeight: FontWeight.w400),
//                                             ),
//                                             const SizedBox(
//                                               height: 4,
//                                             ),
//                                             Text(
//                                               userBooking[index]['sTime'],
//                                               style: GoogleFonts.roboto(
//                                                   fontSize: 25,
//                                                   color: Colors.blueGrey,
//                                                   fontWeight: FontWeight.w400),
//                                             ),
//                                             const SizedBox(
//                                               height: 4,
//                                             ),
//                                             Text(
//                                               userBooking[index]['location'],
//                                               style: GoogleFonts.roboto(
//                                                   fontSize: 25,
//                                                   color: Colors.blueGrey,
//                                                   fontWeight: FontWeight.w400),
//                                             ),
//                                           ],
//                                         ),
//                                         // SizedBox(width: 30,),
//                                       ],
//                                     ),
//                                   ),
//                                   iBefore[index]
//                                       ? Column(
//                                     mainAxisAlignment: MainAxisAlignment.start,
//                                     children: [
//                                       const Text(
//                                         'The remaining time \n          until the reservation begins',
//                                         style: TextStyle(
//                                             fontSize: 21,
//                                             fontWeight: FontWeight.w600,
//                                             color: Colors.blueGrey),
//                                       ),
//                                       const SizedBox(
//                                         height: 15,
//                                       ),
//                                       CustomTimer(
//                                           controller: controller,
//                                           begin: dBefore[index],
//                                           end: const Duration(seconds: 0),
//                                           onChangeState: (CustomTimerState cc) {
//                                             if (cc.name == 'finished') {
//                                               setState(() {
//                                                 iAfter[index]=true;
//                                                 iBefore[index]=false;
//                                                 isBefore = false;
//                                                 isAfter = true;
//                                               });
//                                             }
//                                           },
//                                           builder: (remaining) {
//                                             return Row(
//                                               mainAxisAlignment:
//                                               MainAxisAlignment.center,
//                                               children: [
//                                                 Card(
//                                                   shape: RoundedRectangleBorder(
//                                                       borderRadius:
//                                                       BorderRadius.circular(
//                                                           15)),
//                                                   color:
//                                                   Colors.blueGrey.shade200,
//                                                   elevation: 2,
//                                                   child: Padding(
//                                                     padding:
//                                                     const EdgeInsets.all(
//                                                         8.0),
//                                                     child: Text(
//                                                       remaining.hours,
//                                                       style:
//                                                       GoogleFonts.aBeeZee(
//                                                           fontSize: 35,
//                                                           color: Colors
//                                                               .blueGrey,
//                                                           fontWeight:
//                                                           FontWeight
//                                                               .w800),
//                                                     ),
//                                                   ),
//                                                 ),
//                                                 const Text(
//                                                   ':',
//                                                   style: TextStyle(
//                                                       fontSize: 35,
//                                                       fontWeight:
//                                                       FontWeight.w800),
//                                                 ),
//                                                 Card(
//                                                   shape: RoundedRectangleBorder(
//                                                       borderRadius:
//                                                       BorderRadius.circular(
//                                                           15)),
//                                                   color:
//                                                   Colors.blueGrey.shade200,
//                                                   elevation: 2,
//                                                   child: Padding(
//                                                     padding:
//                                                     const EdgeInsets.all(
//                                                         8.0),
//                                                     child: Text(
//                                                       remaining.minutes,
//                                                       style:
//                                                       GoogleFonts.aBeeZee(
//                                                           fontSize: 35,
//                                                           color: Colors
//                                                               .blueGrey,
//                                                           fontWeight:
//                                                           FontWeight
//                                                               .w800),
//                                                     ),
//                                                   ),
//                                                 ),
//                                                 const Text(
//                                                   ':',
//                                                   style: TextStyle(
//                                                       fontSize: 35,
//                                                       fontWeight:
//                                                       FontWeight.w800),
//                                                 ),
//                                                 Card(
//                                                   shape: RoundedRectangleBorder(
//                                                       borderRadius:
//                                                       BorderRadius.circular(
//                                                           15)),
//                                                   color:
//                                                   Colors.blueGrey.shade200,
//                                                   elevation: 2,
//                                                   child: Padding(
//                                                     padding:
//                                                     const EdgeInsets.all(
//                                                         8.0),
//                                                     child: Text(
//                                                       remaining.seconds,
//                                                       style:
//                                                       GoogleFonts.aBeeZee(
//                                                           fontSize: 35,
//                                                           color: Colors
//                                                               .blueGrey,
//                                                           fontWeight:
//                                                           FontWeight
//                                                               .w800),
//                                                     ),
//                                                   ),
//                                                 ),
//                                               ],
//                                             );
//
//                                             Text(
//                                                 "${remaining.hours}:${remaining
//                                                     .minutes}:${remaining
//                                                     .seconds}",
//                                                 style: const TextStyle(
//                                                     fontSize: 24.0));
//                                           }),
//                                     ],
//                                   )
//                                       : Container(),
//                                   iAfter[index]
//                                       ? Column(
//                                     mainAxisAlignment: MainAxisAlignment.start,
//                                     children: [
//                                       const Text(
//                                         'The remaining time \n          until the end of the reservation',
//                                         style: TextStyle(
//                                             fontSize: 21,
//                                             fontWeight: FontWeight.w600,
//                                             color: Colors.blueGrey),
//                                       ),
//                                       const SizedBox(
//                                         height: 15,
//                                       ),
//                                       CustomTimer(
//                                           controller: controller,
//                                           begin: Duration(minutes: dafter[index]),
//                                           end: const Duration(seconds: 0),
//                                           onChangeState: (CustomTimerState cc) {
//                                             if (cc.name == 'finished') {
//                                               update();
//                                               setState(() {
//                                                 iAfter[index]=false;
//                                                 iBefore[index]=false;
//                                                 isBefore = false;
//                                                 isAfter = false;
//                                               });
//                                             }
//                                           },
//                                           builder: (remaining) {
//                                             return Row(
//                                               mainAxisAlignment:
//                                               MainAxisAlignment.center,
//                                               children: [
//                                                 Card(
//                                                   shape: RoundedRectangleBorder(
//                                                       borderRadius:
//                                                       BorderRadius.circular(
//                                                           15)),
//                                                   color:
//                                                   Colors.blueGrey.shade200,
//                                                   elevation: 2,
//                                                   child: Padding(
//                                                     padding:
//                                                     const EdgeInsets.all(
//                                                         8.0),
//                                                     child: Text(
//                                                       remaining.hours,
//                                                       style:
//                                                       GoogleFonts.aBeeZee(
//                                                           fontSize: 35,
//                                                           color: Colors
//                                                               .blueGrey,
//                                                           fontWeight:
//                                                           FontWeight
//                                                               .w800),
//                                                     ),
//                                                   ),
//                                                 ),
//                                                 const Text(
//                                                   ':',
//                                                   style: TextStyle(
//                                                       fontSize: 35,
//                                                       fontWeight:
//                                                       FontWeight.w800),
//                                                 ),
//                                                 Card(
//                                                   shape: RoundedRectangleBorder(
//                                                       borderRadius:
//                                                       BorderRadius.circular(
//                                                           15)),
//                                                   color:
//                                                   Colors.blueGrey.shade200,
//                                                   elevation: 2,
//                                                   child: Padding(
//                                                     padding:
//                                                     const EdgeInsets.all(
//                                                         8.0),
//                                                     child: Text(
//                                                       remaining.minutes,
//                                                       style:
//                                                       GoogleFonts.aBeeZee(
//                                                           fontSize: 35,
//                                                           color: Colors
//                                                               .blueGrey,
//                                                           fontWeight:
//                                                           FontWeight
//                                                               .w800),
//                                                     ),
//                                                   ),
//                                                 ),
//                                                 const Text(
//                                                   ':',
//                                                   style: TextStyle(
//                                                       fontSize: 35,
//                                                       fontWeight:
//                                                       FontWeight.w800),
//                                                 ),
//                                                 Card(
//                                                   shape: RoundedRectangleBorder(
//                                                       borderRadius:
//                                                       BorderRadius.circular(
//                                                           15)),
//                                                   color:
//                                                   Colors.blueGrey.shade200,
//                                                   elevation: 2,
//                                                   child: Padding(
//                                                     padding:
//                                                     const EdgeInsets.all(
//                                                         8.0),
//                                                     child: Text(
//                                                       remaining.seconds,
//                                                       style:
//                                                       GoogleFonts.aBeeZee(
//                                                           fontSize: 35,
//                                                           color: Colors
//                                                               .blueGrey,
//                                                           fontWeight:
//                                                           FontWeight
//                                                               .w800),
//                                                     ),
//                                                   ),
//                                                 ),
//                                               ],
//                                             );
//                                           }),
//                                     ],
//                                   )
//                                       : Container(),
//                                   firebaseUIButton(context, "end booking", () {
//                                     QuickAlert.show(
//                                       context: context,
//                                       type: QuickAlertType.confirm,
//                                       text:
//                                       'When you click to stop, your position will be canceled',
//                                       confirmBtnText: 'Yes',
//                                       cancelBtnText: 'No',
//                                       confirmBtnColor: Colors.green,
//                                       onConfirmBtnTap: () {
//                                         update();
//                                         push(context, const rate());
//                                       },
//                                     );
//                                   }),
//                                 ],
//                               ),
//                               separatorBuilder: (context, index) => Divider(),
//                               itemCount: userBooking.length),
//                         ),
//                         const SizedBox(
//                           height: 30,
//                         )
//                       ],
//                     ),
//                   ));
//             } else {
//               return const Center(
//                 child: CircularProgressIndicator(),
//               );
//             }
//           },
//         ),
//       ),
//     );
//   }
// }
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:finalproject/screen/timer/appbar.dart';
import 'package:finalproject/screen/timer/clock.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

import 'package:google_fonts/google_fonts.dart';
import 'package:custom_timer/custom_timer.dart';
import 'package:intl/intl.dart';
import 'package:quickalert/models/quickalert_type.dart';
import 'package:quickalert/widgets/quickalert_dialog.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../controller/method.dart';
import '../../widgets/intro.dart';
import '../rate/rate.dart';

class HomeTimer extends StatefulWidget {
  const HomeTimer({super.key});

  @override
  State<HomeTimer> createState() => _HomeTimerState();
}

class _HomeTimerState extends State<HomeTimer> {
  CustomTimerController controller = CustomTimerController();

  var format = DateFormat("HH:mm");
  late DateTime timeNow;
  late DateTime differenceTime;
  late DateTime end;
  late Duration duration;
  late int dura;

  bool isAfter = false;
  bool isBefore = false;
  String? faculty;
  String? time;
  String? location;
  String? sTime;

  void setCounter() {
    var x = DateTime.now();
    var formattedDate = DateFormat('kk:mm').format(x);
    timeNow = format.parse(formattedDate);
    end = format.parse(time!);
    print('--------------------------');
    print('Now    $timeNow');
    print('Time    $time');
    print(end);
    print('--------------------------');
    if (timeNow.isBefore(end)) {
      isAfter = false;
      isBefore = true;
      duration = end.difference(timeNow);
      print('now before end ');
    } else if (timeNow.isAfter(end)) {
      isBefore = false;
      isAfter = true;
      var xx = timeNow
          .difference(end)
          .inMinutes;
      if ((60 - xx >= 0) && (60 - xx) <= 60) {
        dura = 60 - xx;
      } else {
        dura = 0;
      }

      print('end after now');
    } else {
      print('difference = ${end.difference(timeNow)}');
    }
  }

  Future getBook() async {
    var prefs = await SharedPreferences.getInstance();
    faculty = prefs.getString('faculty') ?? "";
    time = prefs.getString('time') ?? "";
    sTime = prefs.getString('sTime') ?? "";
    location = prefs.getString('location') ?? "";
    setCounter();

    return time;
  }

  update() async {
    var updatePosition = FirebaseFirestore.instance
        .collection('parking')
        .doc(faculty)
        .collection('Time')
        .doc(sTime);
    updatePosition.set(
      {
        'position': {location: true}
      },
      SetOptions(merge: true),
    );

    FirebaseFirestore.instance
        .collection('parking')
        .doc(faculty)
        .collection('Time')
        .doc(sTime)
        .get()
        .then((value) {
      var updatePosition = FirebaseFirestore.instance
          .collection('parking')
          .doc(faculty)
          .collection('Time')
          .doc(sTime);
      updatePosition.set(
        {'count': value.data()!['count'] - 1},
        SetOptions(merge: true),
      );
    });
  }

  String? user = FirebaseAuth.instance.currentUser?.uid;
  String name = '';

  getData() async {
    await FirebaseFirestore.instance
        .collection('Users')
        .doc(user)
        .get()
        .then((value) {
      setState(() {
        name = value['Username'];
      });
    });
  }

  @override
  void initState() {
    super.initState();
    getData();
    controller.start();
  }

  @override
  Widget build(BuildContext context) {
    print('time $time');
    var we = MediaQuery
        .of(context)
        .size
        .width;
    var he = MediaQuery
        .of(context)
        .size
        .height;

    return SafeArea(
      child: Scaffold(
        backgroundColor: const Color(0xffE3EDF7),
        body: FutureBuilder(
          future: getBook(),
          builder: (context, snapshot) {
            if (snapshot.hasData) {
              return Container(
                  alignment: Alignment.center,
                  child: Column(
                    children: [
                      const SizedBox(
                        height: 15,
                      ),
                      const Appbars(),
                      const SizedBox(
                        height: 25,
                      ),
                      RichText(
                        text: TextSpan(
                          children: <TextSpan>[
                            TextSpan(
                              text: DateTime
                                  .now()
                                  .hour <= 12
                                  ? 'Good Morning, \n  $name,  '
                                  : 'Good Evening, \n  $name,  ',
                              style: const TextStyle(
                                height: 1.3,
                                color: Colors.blueGrey,
                                fontWeight: FontWeight.w600,
                                fontSize: 20,
                              ),
                            ),
                            const TextSpan(
                              text: 'Have a nice day.!',
                              style: TextStyle(
                                color: Colors.amber,
                                fontWeight: FontWeight.w600,
                                fontSize: 18,
                              ),
                            ),
                          ],
                        ),
                      ),
                      SizedBox(height: he * 0.05),
                      const ClockView(),
                      Container(
                        width: double.infinity,
                        padding: const EdgeInsets.all(9),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: [
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  'Faculty  :',
                                  style: GoogleFonts.roboto(
                                      fontSize: 25,
                                      color: Colors.blueGrey,
                                      fontWeight: FontWeight.w700),
                                ),
                                const SizedBox(
                                  height: 4,
                                ),
                                Text(
                                  'Time  :',
                                  style: GoogleFonts.roboto(
                                      fontSize: 25,
                                      color: Colors.blueGrey,
                                      fontWeight: FontWeight.w700),
                                ),
                                const SizedBox(
                                  height: 4,
                                ),
                                Text(
                                  'Location  :',
                                  style: GoogleFonts.roboto(
                                      fontSize: 25,
                                      color: Colors.blueGrey,
                                      fontWeight: FontWeight.w700),
                                ),
                              ],
                            ),
                            // Expanded(child: Container()),
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  faculty!,
                                  style: GoogleFonts.roboto(
                                      fontSize: 25,
                                      color: Colors.blueGrey,
                                      fontWeight: FontWeight.w400),
                                ),
                                const SizedBox(
                                  height: 4,
                                ),
                                Text(
                                  sTime!,
                                  style: GoogleFonts.roboto(
                                      fontSize: 25,
                                      color: Colors.blueGrey,
                                      fontWeight: FontWeight.w400),
                                ),
                                const SizedBox(
                                  height: 4,
                                ),
                                Text(
                                  location!,
                                  style: GoogleFonts.roboto(
                                      fontSize: 25,
                                      color: Colors.blueGrey,
                                      fontWeight: FontWeight.w400),
                                ),
                              ],
                            ),
                            // SizedBox(width: 30,),
                          ],
                        ),
                      ),
                      isBefore
                          ? Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          const Text(
                            'The remaining time \n          until the reservation begins',
                            style: TextStyle(
                                fontSize: 21,
                                fontWeight: FontWeight.w600,
                                color: Colors.blueGrey),
                          ),
                          const SizedBox(
                            height: 15,
                          ),
                          CustomTimer(
                              controller: controller,
                              begin: duration,
                              end: const Duration(seconds: 0),
                              onChangeState: (CustomTimerState cc) {
                                if (cc.name == 'finished') {
                                  setState(() {
                                    isBefore = false;
                                    isAfter = true;
                                  });
                                }
                              },
                              builder: (remaining) {
                                return Row(
                                  mainAxisAlignment:
                                  MainAxisAlignment.center,
                                  children: [
                                    Card(
                                      shape: RoundedRectangleBorder(
                                          borderRadius:
                                          BorderRadius.circular(15)),
                                      color: Colors.blueGrey.shade200,
                                      elevation: 2,
                                      child: Padding(
                                        padding:
                                        const EdgeInsets.all(8.0),
                                        child: Text(
                                          remaining.hours,
                                          style: GoogleFonts.aBeeZee(
                                              fontSize: 35,
                                              color: Colors.blueGrey,
                                              fontWeight:
                                              FontWeight.w800),
                                        ),
                                      ),
                                    ),
                                    const Text(
                                      ':',
                                      style: TextStyle(
                                          fontSize: 35,
                                          fontWeight: FontWeight.w800),
                                    ),
                                    Card(
                                      shape: RoundedRectangleBorder(
                                          borderRadius:
                                          BorderRadius.circular(15)),
                                      color: Colors.blueGrey.shade200,
                                      elevation: 2,
                                      child: Padding(
                                        padding:
                                        const EdgeInsets.all(8.0),
                                        child: Text(
                                          remaining.minutes,
                                          style: GoogleFonts.aBeeZee(
                                              fontSize: 35,
                                              color: Colors.blueGrey,
                                              fontWeight:
                                              FontWeight.w800),
                                        ),
                                      ),
                                    ),
                                    const Text(
                                      ':',
                                      style: TextStyle(
                                          fontSize: 35,
                                          fontWeight: FontWeight.w800),
                                    ),
                                    Card(
                                      shape: RoundedRectangleBorder(
                                          borderRadius:
                                          BorderRadius.circular(15)),
                                      color: Colors.blueGrey.shade200,
                                      elevation: 2,
                                      child: Padding(
                                        padding:
                                        const EdgeInsets.all(8.0),
                                        child: Text(
                                          remaining.seconds,
                                          style: GoogleFonts.aBeeZee(
                                              fontSize: 35,
                                              color: Colors.blueGrey,
                                              fontWeight:
                                              FontWeight.w800),
                                        ),
                                      ),
                                    ),
                                  ],
                                );

                                Text(
                                    "${remaining.hours}:${remaining
                                        .minutes}:${remaining.seconds}",
                                    style:
                                    const TextStyle(fontSize: 24.0));
                              }),
                        ],
                      )
                          : Container(),
                      isAfter
                          ? Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          const Text(
                            'The remaining time \n          until the end of the reservation',
                            style: TextStyle(
                                fontSize: 21,
                                fontWeight: FontWeight.w600,
                                color: Colors.blueGrey),
                          ),
                          const SizedBox(
                            height: 15,
                          ),
                          CustomTimer(
                              controller: controller,
                              begin: Duration(minutes: dura),
                              end: const Duration(seconds: 0),
                              onChangeState: (CustomTimerState cc) {
                                if (cc.name == 'finished') {
                                  update();
                                  setState(() {
                                    isBefore = false;
                                    isAfter = false;
                                  });
                                }
                              },
                              builder: (remaining) {
                                return Row(
                                  mainAxisAlignment:
                                  MainAxisAlignment.center,
                                  children: [
                                    Card(
                                      shape: RoundedRectangleBorder(
                                          borderRadius:
                                          BorderRadius.circular(15)),
                                      color: Colors.blueGrey.shade200,
                                      elevation: 2,
                                      child: Padding(
                                        padding:
                                        const EdgeInsets.all(8.0),
                                        child: Text(
                                          remaining.hours,
                                          style: GoogleFonts.aBeeZee(
                                              fontSize: 35,
                                              color: Colors.blueGrey,
                                              fontWeight:
                                              FontWeight.w800),
                                        ),
                                      ),
                                    ),
                                    const Text(
                                      ':',
                                      style: TextStyle(
                                          fontSize: 35,
                                          fontWeight: FontWeight.w800),
                                    ),
                                    Card(
                                      shape: RoundedRectangleBorder(
                                          borderRadius:
                                          BorderRadius.circular(15)),
                                      color: Colors.blueGrey.shade200,
                                      elevation: 2,
                                      child: Padding(
                                        padding:
                                        const EdgeInsets.all(8.0),
                                        child: Text(
                                          remaining.minutes,
                                          style: GoogleFonts.aBeeZee(
                                              fontSize: 35,
                                              color: Colors.blueGrey,
                                              fontWeight:
                                              FontWeight.w800),
                                        ),
                                      ),
                                    ),
                                    const Text(
                                      ':',
                                      style: TextStyle(
                                          fontSize: 35,
                                          fontWeight: FontWeight.w800),
                                    ),
                                    Card(
                                      shape: RoundedRectangleBorder(
                                          borderRadius:
                                          BorderRadius.circular(15)),
                                      color: Colors.blueGrey.shade200,
                                      elevation: 2,
                                      child: Padding(
                                        padding:
                                        const EdgeInsets.all(8.0),
                                        child: Text(
                                          remaining.seconds,
                                          style: GoogleFonts.aBeeZee(
                                              fontSize: 35,
                                              color: Colors.blueGrey,
                                              fontWeight:
                                              FontWeight.w800),
                                        ),
                                      ),
                                    ),
                                  ],
                                );
                              }),
                        ],
                      )
                          : Container(),
                      firebaseUIButton(context, "end booking", () {
                        QuickAlert.show(
                            context: context,
                            type: QuickAlertType.confirm,
                            text:
                            'When you click to stop, your position will be canceled',
                            confirmBtnText: 'Yes',
                            cancelBtnText: 'No',
                            confirmBtnColor: Colors.green,
                            onConfirmBtnTap: () {
                              update();
                              push(context, const rate());
                            });
                        const SizedBox(
                          height: 30,
                        );
                      })],
                  ));
            } else {
              return const Center(
                child: CircularProgressIndicator(),
              );
            }
          },
        ),
      ),
    );
  }

}