import 'package:flutter/material.dart';

const Color primaryColor = Color(0xFF36AB95);
const kPrimaryColor = Color.fromARGB(255, 115, 153, 191);
const kPrimaryLightColor = Color(0xfffeeeee4);
